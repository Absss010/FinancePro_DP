﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace FinancePro.Forms
{
    public partial class GlavAutoruz : Form
    {
        private const string connectionString = "Data Source=DESKTOP-2JK9QLP;Initial Catalog=FinancePro;User ID=qwe;Password=qwe;Encrypt=False;TrustServerCertificate=True";
        public GlavAutoruz()
        {
            InitializeComponent();
        }

        private void btnVxod_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text;
            string password = txtPassword.Text;

            // Проверка правильности введенных данных
            if (!IsValidUser(login, password))
            {
                MessageBox.Show("Неправильный логин или пароль.");
                return;
            }

            // Получение роли и ID пользователя
            int roleID = GetUserRole(login);
            int userID = GetUserID(login); 

            // В зависимости от роли, открываем соответствующую форму
            if (roleID == 1)
            {
                AdminPanel adminPanel = new AdminPanel(login, roleID, userID.ToString());
                adminPanel.Show();
            }
            else if (roleID == 2)
            {  
                Ocnovnay ocnovnay = new Ocnovnay(login, roleID, userID.ToString());
                ocnovnay.Show();
            }
            else if (roleID == 3)
            {
                ManagerPanel managerPanel = new ManagerPanel(login, roleID, userID.ToString());
                managerPanel.Show();
            }
            else
            {
                MessageBox.Show("Неизвестная роль пользователя.");
                return;
            }

            this.Hide();
        }

        private bool IsValidUser(string login, string password)
        {
            bool result = false;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT UserPassword, Salt FROM [User] WHERE UserLogin = @Login";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Login", login);
                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string storedPassword = reader.GetString(0);
                            string salt = reader.GetString(1);
                            string hashedPassword = HashPassword(password, salt);

                            if (storedPassword == hashedPassword)
                            {
                                result = true;
                            }
                        }
                    }
                }
            }
            return result;
        }

        private int GetUserRole(string login)
        {
            int roleID = -1;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT RoleID FROM [User] WHERE UserLogin = @Login";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Login", login);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    if (result != null)
                    {
                        roleID = Convert.ToInt32(result);
                    }
                }
            }
            return roleID;
        }

        private int GetUserID(string login)
        {
            int userID = -1;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT UserID FROM [User] WHERE UserLogin = @Login";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Login", login);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    if (result != null)
                    {
                        userID = Convert.ToInt32(result);
                    }
                }
            }
            return userID;
        }

        private string HashPassword(string password, string salt)
        {
            using (var sha256 = SHA256.Create())
            {
                byte[] saltedPassword = Encoding.UTF8.GetBytes(password + salt);
                byte[] hash = sha256.ComputeHash(saltedPassword);
                return Convert.ToBase64String(hash);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Registration registration = new Registration();
            registration.Show();
            this.Hide();
        }
    }
}