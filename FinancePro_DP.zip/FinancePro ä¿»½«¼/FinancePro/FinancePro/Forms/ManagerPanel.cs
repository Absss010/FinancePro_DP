﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinancePro.Forms
{
    public partial class ManagerPanel : Form
    {
        private string login;
        private int roleID;
        private string userID;
        private const string connectionString = "Data Source=DESKTOP-2JK9QLP;Initial Catalog=FinancePro;User ID=qwe;Password=qwe;Encrypt=False;TrustServerCertificate=True";
        public ManagerPanel(string login, int roleID, string userID)
        {
            InitializeComponent();
            this.login = login;
            this.roleID = roleID;
            this.userID = userID;
            LoadInquiries();

            dgvPendingInquiries.SelectionChanged += dgvPendingInquiries_SelectionChanged;
            dgvRespondedInquiries.SelectionChanged += dgvRespondedInquiries_SelectionChanged;
        }
        private void LoadInquiries()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string pendingInquiriesQuery = @"
                    SELECT I.InquiryID, U.UserName + ' ' + U.UserSurname + ' ' + U.UserPatronymic AS FullName, I.Message, I.DateCreated 
                    FROM Inquiry I
                    JOIN [User] U ON I.UserID = U.UserID
                    WHERE I.Status = 'Ожидает ответа'";

                string respondedInquiriesQuery = @"
                    SELECT I.InquiryID, U.UserName + ' ' + U.UserSurname + ' ' + U.UserPatronymic AS FullName, I.Message, I.Response, I.DateCreated, I.DateResponded 
                    FROM Inquiry I
                    JOIN [User] U ON I.UserID = U.UserID
                    WHERE I.Status = 'Отвечено'";

                SqlDataAdapter pendingAdapter = new SqlDataAdapter(new SqlCommand(pendingInquiriesQuery, connection));
                SqlDataAdapter respondedAdapter = new SqlDataAdapter(new SqlCommand(respondedInquiriesQuery, connection));

                DataTable pendingTable = new DataTable();
                DataTable respondedTable = new DataTable();

                pendingAdapter.Fill(pendingTable);
                respondedAdapter.Fill(respondedTable);

                dgvPendingInquiries.DataSource = pendingTable;
                dgvRespondedInquiries.DataSource = respondedTable;

                dgvPendingInquiries.Columns["InquiryID"].Visible = false; 
                dgvPendingInquiries.Columns["FullName"].HeaderText = "ФИО";
                dgvPendingInquiries.Columns["Message"].HeaderText = "Сообщение";
                dgvPendingInquiries.Columns["DateCreated"].HeaderText = "Дата создания";

                dgvRespondedInquiries.Columns["InquiryID"].Visible = false; 
                dgvRespondedInquiries.Columns["FullName"].HeaderText = "ФИО";
                dgvRespondedInquiries.Columns["Message"].HeaderText = "Сообщение";
                dgvRespondedInquiries.Columns["Response"].HeaderText = "Ответ";
                dgvRespondedInquiries.Columns["DateCreated"].HeaderText = "Дата создания";
                dgvRespondedInquiries.Columns["DateResponded"].HeaderText = "Дата ответа";
            }
        }

        private void btnRespond_Click(object sender, EventArgs e)
        {
            if (dgvPendingInquiries.SelectedRows.Count > 0)
            {
                int inquiryID = Convert.ToInt32(dgvPendingInquiries.SelectedRows[0].Cells["InquiryID"].Value);
                string response = txtResponse.Text;

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        string query = "UPDATE Inquiry SET Response = @Response, Status = 'Отвечено', ManagerID = @UserID, DateResponded = GETDATE() WHERE InquiryID = @InquiryID";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Response", response);
                            command.Parameters.AddWithValue("@UserID", userID);
                            command.Parameters.AddWithValue("@InquiryID", inquiryID);
                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Ответ успешно добавлен.");
                            }
                            else
                            {
                                MessageBox.Show("Не удалось обновить запись. Проверьте правильность данных.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при добавлении ответа: {ex.Message}");
                }

                LoadInquiries();
                txtResponse.Clear();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите обращение для ответа.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DataGridView selectedGrid = dgvPendingInquiries.SelectedRows.Count > 0 ? dgvPendingInquiries : dgvRespondedInquiries;

            if (selectedGrid.SelectedRows.Count > 0)
            {
                int inquiryID = Convert.ToInt32(selectedGrid.SelectedRows[0].Cells["InquiryID"].Value);

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        string query = "DELETE FROM Inquiry WHERE InquiryID = @InquiryID";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@InquiryID", inquiryID);
                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Обращение успешно удалено.");
                            }
                            else
                            {
                                MessageBox.Show("Не удалось удалить обращение. Проверьте правильность данных.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении обращения: {ex.Message}");
                }

                LoadInquiries();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите обращение для удаления.");
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvRespondedInquiries.SelectedRows.Count > 0)
            {
                int inquiryID = Convert.ToInt32(dgvRespondedInquiries.SelectedRows[0].Cells["InquiryID"].Value);
                string newResponse = txtResponse.Text;

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        string query = "UPDATE Inquiry SET Response = @Response WHERE InquiryID = @InquiryID";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Response", newResponse);
                            command.Parameters.AddWithValue("@InquiryID", inquiryID);
                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Ответ успешно отредактирован.");
                            }
                            else
                            {
                                MessageBox.Show("Не удалось отредактировать ответ. Проверьте правильность данных.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при редактировании ответа: {ex.Message}");
                }

                LoadInquiries();
                txtResponse.Clear();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите обращение для редактирования.");
            }
        }

        private void dgvPendingInquiries_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvPendingInquiries.SelectedRows.Count > 0)
            {
                txtResponse.Text = string.Empty; 
            }
        }

        private void dgvRespondedInquiries_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvRespondedInquiries.SelectedRows.Count > 0)
            {
                txtResponse.Text = dgvRespondedInquiries.SelectedRows[0].Cells["Response"].Value.ToString();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            GlavAutoruz glavAutoruz = new GlavAutoruz();
            glavAutoruz.Show();
            this.Close();
        }
    }
}