﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinancePro.Forms
{
    public partial class Profile : Form
    {
        private const string connectionString = "Data Source=DESKTOP-2JK9QLP;Initial Catalog=FinancePro;User ID=qwe;Password=qwe;Encrypt=False;TrustServerCertificate=True";
        private string userID;
        private string login;
        private int roleID;

        public Profile(string userID, string login, int roleID)
        {
            InitializeComponent();
            this.userID = userID;
            this.login = login;
            this.roleID = roleID;
            Load += Profile_Load;
            DisplayUserName(login);
        }

        private void DisplayUserName(string login)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT UserSurname, UserName FROM [User] WHERE UserLogin = @Login";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Login", login);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        string surname = reader["UserSurname"].ToString();
                        string name = reader["UserName"].ToString();
                        labName.Text = $"{surname} {name}";
                    }
                    reader.Close();
                }
            }
        }

        private void Profile_Load(object sender, EventArgs e)
        {
            LoadCards();
            cmbDelCard.DropDownStyle = ComboBoxStyle.DropDownList; 
            cmbBalans.DropDownStyle = ComboBoxStyle.DropDownList; 
            cmbBalans.SelectedIndexChanged += cmbBalans_SelectedIndexChanged; 

            if (cmbBalans.SelectedValue != null)
            {
                int selectedCardID = (int)cmbBalans.SelectedValue;
                DisplayCardBalance(selectedCardID);
            }
        }

        private void LoadCards()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT CardID, CardName, AmountCard FROM Card WHERE UserID = @UserID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    cmbDelCard.DataSource = dataTable.Copy();
                    cmbDelCard.DisplayMember = "CardName";
                    cmbDelCard.ValueMember = "CardID";

                    cmbBalans.DataSource = dataTable.Copy();
                    cmbBalans.DisplayMember = "CardName";
                    cmbBalans.ValueMember = "CardID";
                }
            }
        }

        private void cmbBalans_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbBalans.SelectedValue != null)
            {
                int selectedCardID = (int)cmbBalans.SelectedValue;
                DisplayCardBalance(selectedCardID);
            }
        }

        private void DisplayCardBalance(int cardID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT AmountCard FROM Card WHERE CardID = @CardID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CardID", cardID);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        decimal amountCard = (decimal)reader["AmountCard"];
                        labBalans.Text = amountCard.ToString("C2"); // Форматирование как валюту
                        labBalans.ForeColor = amountCard >= 0 ? Color.Lime : Color.Red;
                    }
                    reader.Close();
                }
            }
        }

        private void btnAddCard_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCard.Text))
            {
                MessageBox.Show("Введите название карты.");
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Card (UserID, CardName, AmountCard) VALUES (@UserID, @CardName, @AmountCard)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    command.Parameters.AddWithValue("@CardName", txtCard.Text);
                    command.Parameters.AddWithValue("@AmountCard", 0); 

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Карта успешно добавлена.");
            txtCard.Clear();
            LoadCards();
        }

        private void btnDelCard_Click(object sender, EventArgs e)
        {
            if (cmbDelCard.SelectedValue == null)
            {
                MessageBox.Show("Выберите карту для удаления.");
                return;
            }

            int selectedCardID = (int)cmbDelCard.SelectedValue;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                try
                {
                    string deleteTransactionsQuery = "DELETE FROM [Transaction] WHERE CardID = @CardID";
                    using (SqlCommand deleteTransactionsCommand = new SqlCommand(deleteTransactionsQuery, connection, transaction))
                    {
                        deleteTransactionsCommand.Parameters.AddWithValue("@CardID", selectedCardID);
                        deleteTransactionsCommand.ExecuteNonQuery();
                    }

                    string deleteCardQuery = "DELETE FROM Card WHERE CardID = @CardID";
                    using (SqlCommand deleteCardCommand = new SqlCommand(deleteCardQuery, connection, transaction))
                    {
                        deleteCardCommand.Parameters.AddWithValue("@CardID", selectedCardID);
                        deleteCardCommand.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    MessageBox.Show("Карта и связанные транзакции успешно удалены.");
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show($"Ошибка при удалении карты: {ex.Message}");
                }
            }

            LoadCards();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Ocnovnay ocnovnay = new Ocnovnay(login, roleID, userID);
            ocnovnay.Show();
            Close();
        }
    }
}