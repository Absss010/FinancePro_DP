﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;
using Excel = Microsoft.Office.Interop.Excel;
using System.Drawing.Imaging;


namespace FinancePro.Forms
{
    public partial class History : Form
    {
        private const string connectionString = "Data Source=DESKTOP-2JK9QLP;Initial Catalog=FinancePro;User ID=qwe;Password=qwe;Encrypt=False;TrustServerCertificate=True";
        private string userID;
        private string login;
        private int roleID;

        public History(string userID, string login, int roleID)
        {
            InitializeComponent();
            this.userID = userID;
            this.login = login;
            this.roleID = roleID;
        }

        private void History_Load(object sender, EventArgs e)
        {
            LoadCards(); // Загрузка карт пользователя при открытии формы

            // Автоматически выбираем первую карту из списка, если она доступна
            if (cmbCard.Items.Count > 0)
            {
                cmbCard.SelectedIndex = 0;
                DataRowView selectedRow = cmbCard.SelectedItem as DataRowView;
                int selectedCardID = Convert.ToInt32(selectedRow["CardID"]);
                LoadTransactions($"AND t.CardID = {selectedCardID}"); 
            }
        }

        private void LoadCards()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT CardID, CardName FROM Card WHERE UserID = @UserID";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userID);
                        connection.Open();

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        if (dataTable.Rows.Count == 0)
                        {
                            MessageBox.Show("Нет доступных карт для этого пользователя.");
                        }

                        cmbCard.DataSource = dataTable;
                        cmbCard.DisplayMember = "CardName";
                        cmbCard.ValueMember = "CardID";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке карт: {ex.Message}");
            }
        }

        private void LoadTransactions(string filter = "")
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT t.TransactionID, 
                                u.UserSurname AS 'Фамилия пользователя', 
                                u.UserName AS 'Имя пользователя', 
                                u.UserPatronymic AS 'Отчество пользователя', 
                                t.Amount AS 'Сумма', 
                                ty.TypeName AS 'Тип транзакции', 
                                c.CategoryName AS 'Категория', 
                                t.Date AS 'Дата',
                                cd.CardName AS 'Карта' 
                         FROM [Transaction] t
                         INNER JOIN [User] u ON t.UserID = u.UserID
                         INNER JOIN [Type] ty ON t.TypeID = ty.TypeID
                         INNER JOIN [Category] c ON t.CategoryID = c.CategoryID
                         INNER JOIN [Card] cd ON t.CardID = cd.CardID
                         WHERE t.UserID = @UserID " + filter + @"
                         ORDER BY t.Date DESC";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dgvHistory.DataSource = dataTable;
                    dgvHistory.Columns["TransactionID"].Visible = false; 
                }
            }
        }

        private void cbPlus_CheckedChanged(object sender, EventArgs e)
        {
            DataRowView selectedRow = cmbCard.SelectedItem as DataRowView;
            if (selectedRow != null && cbPlus.Checked)
            {
                cbMinus.Checked = false; 

                int selectedCardID = Convert.ToInt32(selectedRow["CardID"]);
                LoadTransactions($"AND t.Amount > 0 AND t.CardID = {selectedCardID}");
            }
            else if (!cbMinus.Checked) 
            {
                
                cmbCard_SelectedIndexChanged(sender, e);
            }
        }

        private void cbMinus_CheckedChanged(object sender, EventArgs e)
        {
            DataRowView selectedRow = cmbCard.SelectedItem as DataRowView;
            if (selectedRow != null && cbMinus.Checked)
            {
                cbPlus.Checked = false; 

                int selectedCardID = Convert.ToInt32(selectedRow["CardID"]);
                LoadTransactions($"AND t.Amount < 0 AND t.CardID = {selectedCardID}");
            }
            else if (!cbPlus.Checked) 
            {
                
                cmbCard_SelectedIndexChanged(sender, e);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Ocnovnay ocnovnay = new Ocnovnay(login, roleID, userID);
            ocnovnay.Show();
            this.Close();
        }

        private void btnExPlus_Click(object sender, EventArgs e)
        {
            DataRowView selectedRow = cmbCard.SelectedItem as DataRowView;
            if (selectedRow != null)
            {
                int selectedCardID = Convert.ToInt32(selectedRow["CardID"]);
                ExportToExcel($"AND t.Amount > 0 AND t.CardID = {selectedCardID}");
            }
            else
            {
                MessageBox.Show("Выберите карту для экспорта данных.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExMinus_Click(object sender, EventArgs e)
        {
            DataRowView selectedRow = cmbCard.SelectedItem as DataRowView;
            if (selectedRow != null)
            {
                int selectedCardID = Convert.ToInt32(selectedRow["CardID"]);
                ExportToExcel($"AND t.Amount < 0 AND t.CardID = {selectedCardID}");
            }
            else
            {
                MessageBox.Show("Выберите карту для экспорта данных.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExAll_Click(object sender, EventArgs e)
        {
            DataRowView selectedRow = cmbCard.SelectedItem as DataRowView;
            if (selectedRow != null)
            {
                int selectedCardID = Convert.ToInt32(selectedRow["CardID"]);
                ExportToExcel($"AND t.CardID = {selectedCardID}");
            }
            else
            {
                MessageBox.Show("Выберите карту для экспорта данных.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExportToExcel(string filter = "")
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT u.UserSurname AS 'Фамилия пользователя', 
                        u.UserName AS 'Имя пользователя', 
                        u.UserPatronymic AS 'Отчество пользователя', 
                        t.Amount AS 'Сумма', 
                        ty.TypeName AS 'Тип транзакции', 
                        c.CategoryName AS 'Категория', 
                        t.Date AS 'Дата',
                        cd.CardName AS 'Карта' 
                 FROM [Transaction] t
                 INNER JOIN [User] u ON t.UserID = u.UserID
                 INNER JOIN [Type] ty ON t.TypeID = ty.TypeID
                 INNER JOIN [Category] c ON t.CategoryID = c.CategoryID
                 INNER JOIN [Card] cd ON t.CardID = cd.CardID
                 WHERE t.UserID = @UserID " + filter + @"
                 ORDER BY t.Date DESC";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Создание Excel приложения
                    Excel.Application excelApp = new Excel.Application();
                    excelApp.Visible = true;
                    Excel.Workbook workbook = excelApp.Workbooks.Add();
                    Excel.Worksheet worksheet = (Excel.Worksheet)workbook.Sheets[1];

                    // Заполнение данных из DataTable в Excel
                    for (int i = 0; i < dataTable.Columns.Count; i++)
                    {
                        worksheet.Cells[1, i + 1] = dataTable.Columns[i].ColumnName;
                    }

                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        for (int j = 0; j < dataTable.Columns.Count; j++)
                        {
                            if (dataTable.Columns[j].ColumnName == "Дата") 
                            {
                                worksheet.Cells[i + 2, j + 1] = ((DateTime)dataTable.Rows[i][j]).ToString("yyyy-MM-dd"); 
                            }
                            else if (j == 3) 
                            {
                                worksheet.Cells[i + 2, j + 1] = Convert.ToDecimal(dataTable.Rows[i][j]).ToString("N2");
                            }
                            else
                            {
                                worksheet.Cells[i + 2, j + 1] = dataTable.Rows[i][j].ToString();
                            }
                        }
                    }

                    // Форматирование столбца суммы
                    Excel.Range amountColumn = worksheet.Columns[4];
                    amountColumn.NumberFormat = "0.00";

                    worksheet.Columns.AutoFit();
                    MessageBox.Show("Данные успешно экспортированы в Excel.", "Экспорт завершен", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void UpdateCardBalance(int cardID, decimal amount)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Card SET AmountCard = AmountCard + @Amount WHERE CardID = @CardID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Amount", amount);
                    command.Parameters.AddWithValue("@CardID", cardID);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }
        private void DeleteTransaction(int transactionID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Получение информации о транзакции перед удалением
                string selectQuery = "SELECT TypeID, Amount, CardID, CategoryID FROM [Transaction] WHERE TransactionID = @TransactionID";
                using (SqlCommand selectCommand = new SqlCommand(selectQuery, connection))
                {
                    selectCommand.Parameters.AddWithValue("@TransactionID", transactionID);
                    connection.Open();
                    using (SqlDataReader reader = selectCommand.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            int typeID = reader.GetInt32(0);
                            decimal amount = reader.GetDecimal(1);
                            int cardID = reader.GetInt32(2);
                            int categoryID = reader.GetInt32(3);
                            reader.Close();

                            if (categoryID == 8)
                            {
                                if (typeID == 1)
                                {
                                    // Получение ID целевой карты
                                    string targetCardQuery = "SELECT CardID FROM [Transaction] WHERE TransactionID = @TargetTransactionID AND CategoryID = 8";
                                    using (SqlCommand targetCardCommand = new SqlCommand(targetCardQuery, connection))
                                    {
                                        targetCardCommand.Parameters.AddWithValue("@TargetTransactionID", transactionID + 1);
                                        int targetCardID = (int)targetCardCommand.ExecuteScalar();

                                        // Обновление баланса целевой карты
                                        UpdateCardBalance(targetCardID, amount);
                                    }

                                    // Удаление следующей транзакции с CategoryID = 8
                                    string deleteNextQuery = "DELETE FROM [Transaction] WHERE TransactionID = @TransactionID OR (TransactionID = @NextTransactionID AND CategoryID = 8)";
                                    using (SqlCommand deleteNextCommand = new SqlCommand(deleteNextQuery, connection))
                                    {
                                        deleteNextCommand.Parameters.AddWithValue("@TransactionID", transactionID);
                                        deleteNextCommand.Parameters.AddWithValue("@NextTransactionID", transactionID + 1);
                                        deleteNextCommand.ExecuteNonQuery();
                                    }
                                }
                                else if (typeID == 2 && categoryID == 8)
                                {
                                    // Получение ID целевой карты
                                    string targetCardQuery = "SELECT CardID FROM [Transaction] WHERE TransactionID = @TargetTransactionID AND CategoryID = 8";
                                    using (SqlCommand targetCardCommand = new SqlCommand(targetCardQuery, connection))
                                    {
                                        targetCardCommand.Parameters.AddWithValue("@TargetTransactionID", transactionID - 1);
                                        int targetCardID = (int)targetCardCommand.ExecuteScalar();

                                        // Обновление баланса целевой карты
                                        UpdateCardBalance(targetCardID, amount);
                                    }

                                    // Удаление предыдущей транзакции с CategoryID = 8
                                    string deletePrevQuery = "DELETE FROM [Transaction] WHERE TransactionID = @TransactionID OR (TransactionID = @PrevTransactionID AND CategoryID = 8)";
                                    using (SqlCommand deletePrevCommand = new SqlCommand(deletePrevQuery, connection))
                                    {
                                        deletePrevCommand.Parameters.AddWithValue("@TransactionID", transactionID);
                                        deletePrevCommand.Parameters.AddWithValue("@PrevTransactionID", transactionID - 1);
                                        deletePrevCommand.ExecuteNonQuery();
                                    }
                                }
                            }
                            else
                            {
                                // Удаление транзакции для категорий, отличных от 8
                                string deleteQuery = "DELETE FROM [Transaction] WHERE TransactionID = @TransactionID";
                                using (SqlCommand deleteCommand = new SqlCommand(deleteQuery, connection))
                                {
                                    deleteCommand.Parameters.AddWithValue("@TransactionID", transactionID);
                                    deleteCommand.ExecuteNonQuery();
                                }
                            }

                            // Обновление баланса исходной карты
                            UpdateCardBalance(cardID, -amount);
                        }
                    }
                }
            }
        }





        private void btnDelet_Click(object sender, EventArgs e)
        {
            if (dgvHistory.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите транзакцию для удаления.");
                return;
            }

            int selectedTransactionID = (int)dgvHistory.SelectedRows[0].Cells["TransactionID"].Value;
            DeleteTransaction(selectedTransactionID);

            MessageBox.Show("Транзакция успешно удалена.");

            // Получение ID выбранной карты
            DataRowView selectedRow = cmbCard.SelectedItem as DataRowView;
            if (selectedRow != null)
            {
                int selectedCardID = Convert.ToInt32(selectedRow["CardID"]);
                LoadTransactions($"AND t.CardID = {selectedCardID}"); // Обновление DataGridView после удаления транзакции
            }
            else
            {
                LoadTransactions(); // Если карта не выбрана, загружаем все транзакции
            }
        }

        private void cmbCard_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbPlus.Checked = false; 
            cbMinus.Checked = false; 

            DataRowView selectedRow = cmbCard.SelectedItem as DataRowView;
            if (selectedRow != null)
            {
                int selectedCardID = Convert.ToInt32(selectedRow["CardID"]);
                LoadTransactions($"AND t.CardID = {selectedCardID}"); 
            }
            else
            {
                LoadTransactions(); 
            }
        }
    }
}