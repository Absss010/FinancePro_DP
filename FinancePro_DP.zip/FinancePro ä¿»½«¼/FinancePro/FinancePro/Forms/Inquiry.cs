﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinancePro.Forms
{
    public partial class Inquiry : Form
    {
        private const string connectionString = "Data Source=DESKTOP-2JK9QLP;Initial Catalog=FinancePro;User ID=qwe;Password=qwe;Encrypt=False;TrustServerCertificate=True";
        private string userID;
        private string login;
        private int roleID;
        public Inquiry(string userID, string login, int roleID)
        {
            InitializeComponent();
            this.userID = userID;
            this.login = login;
            this.roleID = roleID;
            LoadInquiries();
        }
        private void LoadInquiries()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Message AS 'Сообщение', Response AS 'Ответ', Status AS 'Статус', DateCreated AS 'Дата создания', DateResponded AS 'Дата ответа' FROM Inquiry WHERE UserID = @UserID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dgvInquiries.DataSource = dataTable;

                    if (dgvInquiries.Columns.Contains("InquiryID"))
                    {
                        dgvInquiries.Columns["InquiryID"].Visible = false;
                    }
                }
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Inquiry (UserID, Message, Status) VALUES (@UserID, @Message, 'Ожидает ответа')";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    command.Parameters.AddWithValue("@Message", txtMessage.Text);
                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Вы успешно отправили ваше обращение. \nОтвет поступит в течении одного рабочего дня.");
                }
            }
            LoadInquiries();
            txtMessage.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Ocnovnay ocnovnay = new Ocnovnay(login, roleID, userID);
            ocnovnay.Show();
            this.Close();
        }
    }
}