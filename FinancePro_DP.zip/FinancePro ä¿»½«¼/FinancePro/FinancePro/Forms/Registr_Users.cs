﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinancePro.Forms
{
    public partial class Registr_Users : Form
    {
        private string login;
        private int roleID;
        private string userID;
        private const string connectionString = "Data Source=DESKTOP-2JK9QLP;Initial Catalog=FinancePro;User ID=qwe;Password=qwe;Encrypt=False;TrustServerCertificate=True";

        public Registr_Users(string login, int roleID, string userID)
        {
            InitializeComponent();
            LoadRoles();
            this.login = login;
            this.roleID = roleID;
            this.userID = userID;
        }

        private void LoadRoles()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT RoleID, RoleName FROM Role"; // Изменено на 'Role'
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        cmbRole.Items.Add(new Role
                        {
                            RoleID = reader.GetInt32(0),
                            RoleName = reader.GetString(1)
                        });
                    }
                    cmbRole.DisplayMember = "RoleName";
                    cmbRole.ValueMember = "RoleID";
                }
            }
        }

        private void btnVxod_Click(object sender, EventArgs e)
        {
            string surname = txtSurname.Text;
            string name = txtName.Text;
            string patronymic = txtPatronymic.Text;
            string login = txtLogin.Text;
            string password = txtPassword.Text;

            if (cmbRole.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите роль.");
                return;
            }

            int selectedRoleId = ((Role)cmbRole.SelectedItem).RoleID;

            if (IsLoginExists(login))
            {
                MessageBox.Show("Данный логин уже занят, выберите другой.");
                return;
            }

            string salt = GenerateSalt();
            string hashedPassword = HashPassword(password, salt);
            RegisterUser(surname, name, patronymic, login, hashedPassword, salt, selectedRoleId);

            MessageBox.Show("Регистрация прошла успешно!");
            AdminPanel adminPanel = new AdminPanel(login, roleID, userID);
            adminPanel.Show();
            this.Close();
        }

        private bool IsLoginExists(string login)
        {
            bool result = false;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT COUNT(*) FROM [User] WHERE UserLogin = @Login";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Login", login);
                    connection.Open();
                    int count = (int)command.ExecuteScalar();
                    if (count > 0)
                    {
                        result = true;
                    }
                }
            }
            return result;
        }

        private void RegisterUser(string surname, string name, string patronymic, string login, string hashedPassword, string salt, int roleId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO [User] (UserSurname, UserName, UserPatronymic, UserLogin, UserPassword, Salt, RoleID) VALUES (@Surname, @Name, @Patronymic, @Login, @Password, @Salt, @RoleID)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Surname", surname);
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Patronymic", patronymic);
                    command.Parameters.AddWithValue("@Login", login);
                    command.Parameters.AddWithValue("@Password", hashedPassword);
                    command.Parameters.AddWithValue("@Salt", salt);
                    command.Parameters.AddWithValue("@RoleID", roleId);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        private string GenerateSalt()
        {
            byte[] saltBytes = new byte[16];
            using (var rng = new RNGCryptoServiceProvider())
            {
                rng.GetBytes(saltBytes);
            }
            return Convert.ToBase64String(saltBytes);
        }

        private string HashPassword(string password, string salt)
        {
            using (var sha256 = SHA256.Create())
            {
                byte[] saltedPassword = Encoding.UTF8.GetBytes(password + salt);
                byte[] hash = sha256.ComputeHash(saltedPassword);
                return Convert.ToBase64String(hash);
            }
        }

        private void btnGlav_Click(object sender, EventArgs e)
        {
            AdminPanel adminPanel = new AdminPanel(login, roleID, userID);
            adminPanel.Show();
            this.Close();
        }
    }

    public class Role
    {
        public int RoleID { get; set; }
        public string RoleName { get; set; }
    }
}