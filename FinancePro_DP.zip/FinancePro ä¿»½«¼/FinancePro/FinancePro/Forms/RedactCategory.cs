﻿using FinancePro.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinancePro
{
    public partial class RedactCategory : Form
    {
        private const string connectionString = "Data Source=DESKTOP-2JK9QLP;Initial Catalog=FinancePro;User ID=qwe;Password=qwe;Encrypt=False;TrustServerCertificate=True";
        private string userID;
        private string login;
        private int roleID;

        public RedactCategory(string userID, string login, int roleID)
        {
            InitializeComponent();
            this.userID = userID;
            this.login = login;
            this.roleID = roleID;
        }

        private void RedactCategory_Load(object sender, EventArgs e)
        {
            LoadCategories();
        }

        private void LoadCategories()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT CategoryID, CategoryName FROM Category";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dgvCategory.DataSource = dataTable;
                        dgvCategory.Columns["CategoryID"].Visible = false; 
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке категорий: {ex.Message}");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string categoryName = txtCategory.Text.Trim();
            if (string.IsNullOrEmpty(categoryName))
            {
                MessageBox.Show("Введите название категории.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Category (CategoryName) VALUES (@CategoryName)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@CategoryName", categoryName);
                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Категория успешно добавлена.");
                LoadCategories(); 
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении категории: {ex.Message}");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvCategory.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите категорию для удаления.");
                return;
            }

            int selectedCategoryID = (int)dgvCategory.SelectedRows[0].Cells["CategoryID"].Value;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    SqlTransaction transaction = connection.BeginTransaction();

                    try
                    {
                        string selectTransactionsQuery = "SELECT TransactionID, CardID, Amount FROM [Transaction] WHERE CategoryID = @CategoryID";
                        List<Tuple<int, int, decimal>> transactions = new List<Tuple<int, int, decimal>>();
                        using (SqlCommand selectTransactionsCommand = new SqlCommand(selectTransactionsQuery, connection, transaction))
                        {
                            selectTransactionsCommand.Parameters.AddWithValue("@CategoryID", selectedCategoryID);
                            using (SqlDataReader reader = selectTransactionsCommand.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    int transactionID = reader.GetInt32(0);
                                    int cardID = reader.GetInt32(1);
                                    decimal amount = reader.GetDecimal(2);
                                    transactions.Add(new Tuple<int, int, decimal>(transactionID, cardID, amount));
                                }
                            }
                        }
                        foreach (var transactionData in transactions)
                        {
                            int transactionID = transactionData.Item1;
                            int cardID = transactionData.Item2;
                            decimal amount = transactionData.Item3;

                            UpdateCardBalance(cardID, -amount, connection, transaction);

                            DeleteTransaction(transactionID, connection, transaction);
                        }

                        string deleteCategoryQuery = "DELETE FROM Category WHERE CategoryID = @CategoryID";
                        using (SqlCommand deleteCategoryCommand = new SqlCommand(deleteCategoryQuery, connection, transaction))
                        {
                            deleteCategoryCommand.Parameters.AddWithValue("@CategoryID", selectedCategoryID);
                            deleteCategoryCommand.ExecuteNonQuery();
                        }

                        transaction.Commit();
                        MessageBox.Show("Категория и связанные с ней транзакции успешно удалены.");
                        LoadCategories(); // Обновляем список категорий после удаления
                    }
                    catch (Exception ex)
                    {
                        // Откат транзакции в случае ошибки
                        transaction.Rollback();
                        MessageBox.Show($"Ошибка при удалении категории: {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при подключении к базе данных: {ex.Message}");
            }
        }

        private void UpdateCardBalance(int cardID, decimal amount, SqlConnection connection, SqlTransaction transaction)
        {
            string query = "UPDATE Card SET AmountCard = AmountCard + @Amount WHERE CardID = @CardID";
            using (SqlCommand command = new SqlCommand(query, connection, transaction))
            {
                command.Parameters.AddWithValue("@Amount", amount);
                command.Parameters.AddWithValue("@CardID", cardID);
                command.ExecuteNonQuery();
            }
        }

        private void DeleteTransaction(int transactionID, SqlConnection connection, SqlTransaction transaction)
        {
            string deleteTransactionQuery = "DELETE FROM [Transaction] WHERE TransactionID = @TransactionID";
            using (SqlCommand deleteTransactionCommand = new SqlCommand(deleteTransactionQuery, connection, transaction))
            {
                deleteTransactionCommand.Parameters.AddWithValue("@TransactionID", transactionID);
                deleteTransactionCommand.ExecuteNonQuery();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            AdminPanel adminPanel = new AdminPanel(login, roleID, userID);
            adminPanel.Show();
            this.Close();
        }
    }
}