﻿namespace FinancePro.Forms
{
    partial class Profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Profile));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.btnExit = new System.Windows.Forms.ToolStripMenuItem();
            this.label2 = new System.Windows.Forms.Label();
            this.labBalans = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCard = new System.Windows.Forms.TextBox();
            this.cmbDelCard = new System.Windows.Forms.ComboBox();
            this.btnAddCard = new System.Windows.Forms.Button();
            this.btnDelCard = new System.Windows.Forms.Button();
            this.labPoz = new System.Windows.Forms.Label();
            this.labName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbBalans = new System.Windows.Forms.ComboBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnExit});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(479, 24);
            this.menuStrip1.TabIndex = 14;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // btnExit
            // 
            this.btnExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(63, 20);
            this.btnExit.Text = "Главная";
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.Azure;
            this.label2.Location = new System.Drawing.Point(12, 274);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 27);
            this.label2.TabIndex = 15;
            this.label2.Text = "Баланс карты -";
            // 
            // labBalans
            // 
            this.labBalans.AutoSize = true;
            this.labBalans.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labBalans.ForeColor = System.Drawing.Color.Azure;
            this.labBalans.Location = new System.Drawing.Point(309, 275);
            this.labBalans.Name = "labBalans";
            this.labBalans.Size = new System.Drawing.Size(36, 27);
            this.labBalans.TabIndex = 16;
            this.labBalans.Text = "...";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(71, 78);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(212, 23);
            this.label6.TabIndex = 23;
            this.label6.Text = "Добавить новую карту - ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(135, 174);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(148, 23);
            this.label7.TabIndex = 24;
            this.label7.Text = "Удалить карту - ";
            // 
            // txtCard
            // 
            this.txtCard.Location = new System.Drawing.Point(289, 82);
            this.txtCard.Name = "txtCard";
            this.txtCard.Size = new System.Drawing.Size(100, 20);
            this.txtCard.TabIndex = 25;
            // 
            // cmbDelCard
            // 
            this.cmbDelCard.FormattingEnabled = true;
            this.cmbDelCard.Location = new System.Drawing.Point(277, 178);
            this.cmbDelCard.Name = "cmbDelCard";
            this.cmbDelCard.Size = new System.Drawing.Size(126, 21);
            this.cmbDelCard.TabIndex = 26;
            // 
            // btnAddCard
            // 
            this.btnAddCard.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnAddCard.Location = new System.Drawing.Point(277, 108);
            this.btnAddCard.Name = "btnAddCard";
            this.btnAddCard.Size = new System.Drawing.Size(126, 32);
            this.btnAddCard.TabIndex = 27;
            this.btnAddCard.Text = "Подтвердить";
            this.btnAddCard.UseVisualStyleBackColor = true;
            this.btnAddCard.Click += new System.EventHandler(this.btnAddCard_Click);
            // 
            // btnDelCard
            // 
            this.btnDelCard.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDelCard.Location = new System.Drawing.Point(277, 205);
            this.btnDelCard.Name = "btnDelCard";
            this.btnDelCard.Size = new System.Drawing.Size(126, 32);
            this.btnDelCard.TabIndex = 28;
            this.btnDelCard.Text = "Подтвердить";
            this.btnDelCard.UseVisualStyleBackColor = true;
            this.btnDelCard.Click += new System.EventHandler(this.btnDelCard_Click);
            // 
            // labPoz
            // 
            this.labPoz.AutoSize = true;
            this.labPoz.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labPoz.Location = new System.Drawing.Point(115, 39);
            this.labPoz.Name = "labPoz";
            this.labPoz.Size = new System.Drawing.Size(145, 27);
            this.labPoz.TabIndex = 30;
            this.labPoz.Text = "Здравствуйте,";
            // 
            // labName
            // 
            this.labName.AutoSize = true;
            this.labName.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labName.Location = new System.Drawing.Point(254, 39);
            this.labName.Name = "labName";
            this.labName.Size = new System.Drawing.Size(36, 27);
            this.labName.TabIndex = 29;
            this.labName.Text = "...";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(150, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 30);
            this.label1.TabIndex = 31;
            this.label1.Text = "Личный профиль";
            // 
            // cmbBalans
            // 
            this.cmbBalans.FormattingEnabled = true;
            this.cmbBalans.Location = new System.Drawing.Point(177, 280);
            this.cmbBalans.Name = "cmbBalans";
            this.cmbBalans.Size = new System.Drawing.Size(126, 21);
            this.cmbBalans.TabIndex = 32;
            // 
            // Profile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(479, 329);
            this.Controls.Add(this.cmbBalans);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labPoz);
            this.Controls.Add(this.labName);
            this.Controls.Add(this.btnDelCard);
            this.Controls.Add(this.btnAddCard);
            this.Controls.Add(this.cmbDelCard);
            this.Controls.Add(this.txtCard);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.labBalans);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Profile";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Личный профиль";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem btnExit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labBalans;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCard;
        private System.Windows.Forms.ComboBox cmbDelCard;
        private System.Windows.Forms.Button btnAddCard;
        private System.Windows.Forms.Button btnDelCard;
        private System.Windows.Forms.Label labPoz;
        private System.Windows.Forms.Label labName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbBalans;
    }
}