﻿namespace FinancePro.Forms
{
    partial class Ocnovnay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Ocnovnay));
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.менюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnTransaction = new System.Windows.Forms.ToolStripMenuItem();
            this.btnHistory = new System.Windows.Forms.ToolStripMenuItem();
            this.уведомленияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.профильToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnExitAc = new System.Windows.Forms.ToolStripMenuItem();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.labPoz = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labNedPlus = new System.Windows.Forms.Label();
            this.labMesPlus = new System.Windows.Forms.Label();
            this.labNedMinus = new System.Windows.Forms.Label();
            this.labMesMinus = new System.Windows.Forms.Label();
            this.chartTransactionPlus = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.chartTransactionMinus = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbCard = new System.Windows.Forms.ComboBox();
            this.labBalans = new System.Windows.Forms.Label();
            this.поддержкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartTransactionPlus)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartTransactionMinus)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(327, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 30);
            this.label1.TabIndex = 5;
            this.label1.Text = "Аналитика";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.менюToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(784, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // менюToolStripMenuItem
            // 
            this.менюToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnTransaction,
            this.уведомленияToolStripMenuItem,
            this.профильToolStripMenuItem,
            this.поддержкаToolStripMenuItem,
            this.btnExitAc});
            this.менюToolStripMenuItem.Name = "менюToolStripMenuItem";
            this.менюToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.менюToolStripMenuItem.Text = "Меню";
            // 
            // btnTransaction
            // 
            this.btnTransaction.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnHistory});
            this.btnTransaction.Name = "btnTransaction";
            this.btnTransaction.Size = new System.Drawing.Size(180, 22);
            this.btnTransaction.Text = "Транзакциии";
            this.btnTransaction.Click += new System.EventHandler(this.btnTransaction_Click);
            // 
            // btnHistory
            // 
            this.btnHistory.Name = "btnHistory";
            this.btnHistory.Size = new System.Drawing.Size(121, 22);
            this.btnHistory.Text = "История";
            this.btnHistory.Click += new System.EventHandler(this.btnHistory_Click);
            // 
            // уведомленияToolStripMenuItem
            // 
            this.уведомленияToolStripMenuItem.Name = "уведомленияToolStripMenuItem";
            this.уведомленияToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.уведомленияToolStripMenuItem.Text = "Напоминания";
            this.уведомленияToolStripMenuItem.Click += new System.EventHandler(this.уведомленияToolStripMenuItem_Click);
            // 
            // профильToolStripMenuItem
            // 
            this.профильToolStripMenuItem.Name = "профильToolStripMenuItem";
            this.профильToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.профильToolStripMenuItem.Text = "Профиль";
            this.профильToolStripMenuItem.Click += new System.EventHandler(this.профильToolStripMenuItem_Click);
            // 
            // btnExitAc
            // 
            this.btnExitAc.Name = "btnExitAc";
            this.btnExitAc.Size = new System.Drawing.Size(180, 22);
            this.btnExitAc.Text = "Выход из аккаунта";
            this.btnExitAc.Click += new System.EventHandler(this.выходИзАккаунтаToolStripMenuItem_Click);
            // 
            // labPoz
            // 
            this.labPoz.AutoSize = true;
            this.labPoz.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labPoz.Location = new System.Drawing.Point(12, 430);
            this.labPoz.Name = "labPoz";
            this.labPoz.Size = new System.Drawing.Size(122, 19);
            this.labPoz.TabIndex = 8;
            this.labPoz.Text = "Выберите карту -";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(3, 272);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(206, 23);
            this.label2.TabIndex = 9;
            this.label2.Text = "Пополнение за неделю:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(16, 312);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(193, 23);
            this.label3.TabIndex = 10;
            this.label3.Text = "Пополнение за месяц:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(2, 274);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(157, 23);
            this.label4.TabIndex = 11;
            this.label4.Text = "Траты за неделю:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(15, 314);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(144, 23);
            this.label5.TabIndex = 12;
            this.label5.Text = "Траты за месяц:";
            // 
            // labNedPlus
            // 
            this.labNedPlus.AutoSize = true;
            this.labNedPlus.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labNedPlus.ForeColor = System.Drawing.Color.Lime;
            this.labNedPlus.Location = new System.Drawing.Point(205, 274);
            this.labNedPlus.Name = "labNedPlus";
            this.labNedPlus.Size = new System.Drawing.Size(31, 21);
            this.labNedPlus.TabIndex = 13;
            this.labNedPlus.Text = "...";
            // 
            // labMesPlus
            // 
            this.labMesPlus.AutoSize = true;
            this.labMesPlus.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labMesPlus.ForeColor = System.Drawing.Color.Lime;
            this.labMesPlus.Location = new System.Drawing.Point(205, 314);
            this.labMesPlus.Name = "labMesPlus";
            this.labMesPlus.Size = new System.Drawing.Size(31, 21);
            this.labMesPlus.TabIndex = 14;
            this.labMesPlus.Text = "...";
            // 
            // labNedMinus
            // 
            this.labNedMinus.AutoSize = true;
            this.labNedMinus.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labNedMinus.ForeColor = System.Drawing.Color.Red;
            this.labNedMinus.Location = new System.Drawing.Point(156, 276);
            this.labNedMinus.Name = "labNedMinus";
            this.labNedMinus.Size = new System.Drawing.Size(31, 21);
            this.labNedMinus.TabIndex = 15;
            this.labNedMinus.Text = "...";
            // 
            // labMesMinus
            // 
            this.labMesMinus.AutoSize = true;
            this.labMesMinus.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labMesMinus.ForeColor = System.Drawing.Color.Red;
            this.labMesMinus.Location = new System.Drawing.Point(156, 316);
            this.labMesMinus.Name = "labMesMinus";
            this.labMesMinus.Size = new System.Drawing.Size(31, 21);
            this.labMesMinus.TabIndex = 16;
            this.labMesMinus.Text = "...";
            // 
            // chartTransactionPlus
            // 
            this.chartTransactionPlus.BackColor = System.Drawing.Color.DimGray;
            this.chartTransactionPlus.BorderSkin.BackImageTransparentColor = System.Drawing.Color.DimGray;
            this.chartTransactionPlus.BorderSkin.BackSecondaryColor = System.Drawing.Color.DimGray;
            this.chartTransactionPlus.BorderSkin.BorderColor = System.Drawing.Color.DimGray;
            this.chartTransactionPlus.BorderSkin.PageColor = System.Drawing.Color.Transparent;
            this.chartTransactionPlus.BorderSkin.SkinStyle = System.Windows.Forms.DataVisualization.Charting.BorderSkinStyle.FrameThin6;
            chartArea1.BackColor = System.Drawing.Color.DimGray;
            chartArea1.Name = "ChartArea1";
            this.chartTransactionPlus.ChartAreas.Add(chartArea1);
            legend1.BackColor = System.Drawing.Color.Gray;
            legend1.Name = "Legend1";
            this.chartTransactionPlus.Legends.Add(legend1);
            this.chartTransactionPlus.Location = new System.Drawing.Point(10, 47);
            this.chartTransactionPlus.Name = "chartTransactionPlus";
            this.chartTransactionPlus.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SeaGreen;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chartTransactionPlus.Series.Add(series1);
            this.chartTransactionPlus.Size = new System.Drawing.Size(330, 191);
            this.chartTransactionPlus.TabIndex = 17;
            this.chartTransactionPlus.Text = "chart1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label6.Location = new System.Drawing.Point(77, 241);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(187, 19);
            this.label6.TabIndex = 20;
            this.label6.Text = "Из учета ваших транзакций";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.labMesMinus);
            this.panel1.Controls.Add(this.chartTransactionMinus);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.labNedMinus);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(404, 53);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(350, 357);
            this.panel1.TabIndex = 29;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(140, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 27);
            this.label7.TabIndex = 31;
            this.label7.Text = "Расход";
            // 
            // chartTransactionMinus
            // 
            this.chartTransactionMinus.BackColor = System.Drawing.Color.DimGray;
            this.chartTransactionMinus.BorderlineColor = System.Drawing.Color.Transparent;
            this.chartTransactionMinus.BorderSkin.BackColor = System.Drawing.Color.DimGray;
            this.chartTransactionMinus.BorderSkin.BackImageTransparentColor = System.Drawing.Color.DimGray;
            this.chartTransactionMinus.BorderSkin.BackSecondaryColor = System.Drawing.Color.DimGray;
            this.chartTransactionMinus.BorderSkin.BorderColor = System.Drawing.Color.DimGray;
            this.chartTransactionMinus.BorderSkin.PageColor = System.Drawing.Color.Transparent;
            this.chartTransactionMinus.BorderSkin.SkinStyle = System.Windows.Forms.DataVisualization.Charting.BorderSkinStyle.FrameThin6;
            chartArea2.BackColor = System.Drawing.Color.DimGray;
            chartArea2.Name = "ChartArea1";
            this.chartTransactionMinus.ChartAreas.Add(chartArea2);
            legend2.BackColor = System.Drawing.Color.Gray;
            legend2.Name = "Legend1";
            legend2.TitleAlignment = System.Drawing.StringAlignment.Near;
            this.chartTransactionMinus.Legends.Add(legend2);
            this.chartTransactionMinus.Location = new System.Drawing.Point(10, 47);
            this.chartTransactionMinus.Name = "chartTransactionMinus";
            this.chartTransactionMinus.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.EarthTones;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chartTransactionMinus.Series.Add(series2);
            this.chartTransactionMinus.Size = new System.Drawing.Size(330, 191);
            this.chartTransactionMinus.TabIndex = 30;
            this.chartTransactionMinus.Text = "chart1";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.chartTransactionPlus);
            this.panel2.Controls.Add(this.labNedPlus);
            this.panel2.Controls.Add(this.labMesPlus);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(29, 53);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(350, 357);
            this.panel2.TabIndex = 32;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.Color.Lime;
            this.label8.Location = new System.Drawing.Point(138, 17);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 27);
            this.label8.TabIndex = 31;
            this.label8.Text = "Доход";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label9.Location = new System.Drawing.Point(76, 241);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(187, 19);
            this.label9.TabIndex = 20;
            this.label9.Text = "Из учета ваших транзакций";
            // 
            // cmbCard
            // 
            this.cmbCard.FormattingEnabled = true;
            this.cmbCard.Location = new System.Drawing.Point(140, 431);
            this.cmbCard.Name = "cmbCard";
            this.cmbCard.Size = new System.Drawing.Size(121, 21);
            this.cmbCard.TabIndex = 33;
            // 
            // labBalans
            // 
            this.labBalans.AutoSize = true;
            this.labBalans.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labBalans.Location = new System.Drawing.Point(276, 430);
            this.labBalans.Name = "labBalans";
            this.labBalans.Size = new System.Drawing.Size(27, 19);
            this.labBalans.TabIndex = 32;
            this.labBalans.Text = "...";
            // 
            // поддержкаToolStripMenuItem
            // 
            this.поддержкаToolStripMenuItem.Name = "поддержкаToolStripMenuItem";
            this.поддержкаToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.поддержкаToolStripMenuItem.Text = "Поддержка";
            this.поддержкаToolStripMenuItem.Click += new System.EventHandler(this.поддержкаToolStripMenuItem_Click);
            // 
            // Ocnovnay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.labBalans);
            this.Controls.Add(this.cmbCard);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.labPoz);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Ocnovnay";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Главная";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartTransactionPlus)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartTransactionMinus)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem менюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem btnTransaction;
        private System.Windows.Forms.ToolStripMenuItem btnHistory;
        private System.Windows.Forms.ToolStripMenuItem уведомленияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem btnExitAc;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Label labPoz;
        private System.Windows.Forms.ToolStripMenuItem профильToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labNedPlus;
        private System.Windows.Forms.Label labMesPlus;
        private System.Windows.Forms.Label labNedMinus;
        private System.Windows.Forms.Label labMesMinus;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartTransactionPlus;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartTransactionMinus;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbCard;
        private System.Windows.Forms.Label labBalans;
        private System.Windows.Forms.ToolStripMenuItem поддержкаToolStripMenuItem;
    }
}