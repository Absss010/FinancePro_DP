﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace FinancePro.Forms
{
    public partial class Ocnovnay : Form
    {
        private string login;
        private int roleID;
        private string userID;
        private const string connectionString = "Data Source=DESKTOP-2JK9QLP;Initial Catalog=FinancePro;User ID=qwe;Password=qwe;Encrypt=False;TrustServerCertificate=True";

        public Ocnovnay(string login, int roleID, string userID)
        {
            InitializeComponent();
            this.login = login;
            this.roleID = roleID;
            this.userID = userID;

            this.Load += Ocnovnay_Load;

            cmbCard.SelectedIndexChanged += cmbCard_SelectedIndexChanged;
        }

        private void LoadCards()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT CardID, CardName FROM Card WHERE UserID = @UserID";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userID);
                        connection.Open();

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        if (dataTable.Rows.Count == 0)
                        {
                            MessageBox.Show("Нет доступных карт для этого пользователя.\n Пожалуйста добавьте карту в профиле.");
                        }

                        cmbCard.DataSource = dataTable;
                        cmbCard.DisplayMember = "CardName";
                        cmbCard.ValueMember = "CardID";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке карт: {ex.Message}");
            }
        }

        private void Ocnovnay_Load(object sender, EventArgs e)
        {
            LoadCards();
            cmbCard.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void cmbCard_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCard.SelectedItem != null)
            {
                DataRowView selectedRow = cmbCard.SelectedItem as DataRowView;
                if (selectedRow != null)
                {
                    int selectedCardID = Convert.ToInt32(selectedRow["CardID"]);
                    UpdateLabels(Convert.ToInt32(userID), selectedCardID);
                    UpdateCardBalance(selectedCardID); // Обновляем баланс при выборе карты
                }
            }
        }

        private void UpdateCardBalance(int cardID)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT AmountCard FROM Card WHERE CardID = @CardID";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@CardID", cardID);
                        connection.Open();

                        object result = command.ExecuteScalar();
                        if (result != DBNull.Value)
                        {
                            decimal balance = Convert.ToDecimal(result);
                            labBalans.Text = $"Баланс карты: {balance:C}";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при получении баланса карты: {ex.Message}");
            }
        }

        private void UpdateLabels(int userID, int cardID)
        {
            DateTime today = DateTime.Today;
            DateTime startOfMonth = new DateTime(today.Year, today.Month, 1);
            DateTime startOfWeek = today.AddDays(-(int)today.DayOfWeek + (int)DayOfWeek.Monday);

            decimal monthIncome = GetTotalAmountForPeriod(userID, startOfMonth, today, false, cardID);
            decimal monthExpense = GetTotalAmountForPeriod(userID, startOfMonth, today, true, cardID);

            decimal weekIncome = GetTotalAmountForPeriod(userID, startOfWeek, today, false, cardID);
            decimal weekExpense = GetTotalAmountForPeriod(userID, startOfWeek, today, true, cardID);

            labMesPlus.Text = $"{monthIncome:C}";
            labMesMinus.Text = $"{monthExpense:C}";

            labNedPlus.Text = $"{weekIncome:C}";
            labNedMinus.Text = $"{weekExpense:C}";

            UpdateChart(userID, "chartTransactionPlus", false, startOfMonth, today, cardID);
            UpdateChart(userID, "chartTransactionMinus", true, startOfMonth, today, cardID);
        }

        private decimal GetTotalAmountForPeriod(int userID, DateTime startDate, DateTime endDate, bool isExpense, int cardID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"
                    SELECT SUM(Amount) 
                    FROM [Transaction] 
                    WHERE UserID = @UserID 
                      AND CardID = @CardID
                      AND Date BETWEEN @StartDate AND @EndDate 
                      AND Amount " + (isExpense ? "< 0" : "> 0");

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    command.Parameters.AddWithValue("@CardID", cardID);
                    command.Parameters.AddWithValue("@StartDate", startDate);
                    command.Parameters.AddWithValue("@EndDate", endDate);

                    connection.Open();
                    object result = command.ExecuteScalar();
                    return result != DBNull.Value ? Convert.ToDecimal(result) : 0;
                }
            }
        }

        private void UpdateChart(int userID, string chartName, bool isExpense, DateTime startDate, DateTime endDate, int cardID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"
                    SELECT C.CategoryName, SUM(T.Amount) as TotalAmount 
                    FROM [Transaction] T 
                    JOIN [Category] C ON T.CategoryID = C.CategoryID 
                    WHERE T.UserID = @UserID 
                      AND T.CardID = @CardID
                      AND T.Amount " + (isExpense ? "< 0" : "> 0") + @"
                      AND T.Date BETWEEN @StartDate AND @EndDate
                    GROUP BY C.CategoryName";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    command.Parameters.AddWithValue("@CardID", cardID);
                    command.Parameters.AddWithValue("@StartDate", startDate);
                    command.Parameters.AddWithValue("@EndDate", endDate);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    Chart chart = this.Controls.Find(chartName, true).FirstOrDefault() as Chart;
                    if (chart != null)
                    {
                        chart.Series.Clear();
                        chart.Titles.Clear();
                        chart.BackColor = Color.DimGray;

                        Series series = new Series
                        {
                            Name = "Series1",
                            IsVisibleInLegend = true,
                            Color = System.Drawing.Color.Green,
                            ChartType = SeriesChartType.Pie,
                            Font = new Font("Arial", 8, FontStyle.Bold), 
                        };

                        chart.Series.Add(series);

                        while (reader.Read())
                        {
                            DataPoint point = new DataPoint();
                            point.SetValueXY(reader["CategoryName"].ToString(), reader["TotalAmount"]);
                            point.LabelForeColor = Color.Transparent; 
                            series.Points.Add(point);
                        }
                    }
                    reader.Close();
                }
            }
        }

        private void выходИзАккаунтаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GlavAutoruz glavAutoruz = new GlavAutoruz();
            glavAutoruz.Show();
            this.Close();
        }

        private void btnTransaction_Click(object sender, EventArgs e)
        {
            Transaction transaction = new Transaction(userID, login, roleID);
            transaction.Show();
            this.Close();
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            History history = new History(userID, login, roleID);
            history.Show();
            this.Close();
        }

        private void профильToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Profile profile = new Profile(userID, login, roleID);
            profile.Show();
            this.Close();
        }

        private void уведомленияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Notification notification = new Notification(userID, login, roleID);
            notification.Show();
            this.Close();
        }

        private void поддержкаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Inquiry inquiry = new Inquiry(userID, login, roleID);
            inquiry.Show();
            this.Close();
        }
    }
}