﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace FinancePro.Forms
{
    public partial class Registration : Form
    {
        private const string connectionString = "Data Source=DESKTOP-2JK9QLP;Initial Catalog=FinancePro;User ID=qwe;Password=qwe;Encrypt=False;TrustServerCertificate=True";

        public Registration()
        {
            InitializeComponent();
        }

        private void btnVxod_Click(object sender, EventArgs e)
        {
            string surname = txtSurname.Text;
            string name = txtName.Text;
            string patronymic = txtPatronymic.Text;
            string login = txtLogin.Text;
            string password = txtPassword.Text;

            // Проверка наличия логина в базе данных
            if (IsLoginExists(login))
            {
                MessageBox.Show("Данный логин уже занят, выберите другой.");
                return;
            }

            // Генерация соли
            string salt = GenerateSalt();

            // Хеширование пароля с солью
            string hashedPassword = HashPassword(password, salt);

            // Регистрация нового пользователя
            RegisterUser(surname, name, patronymic, login, hashedPassword, salt);

            MessageBox.Show("Регистрация прошла успешно!");
            GlavAutoruz glavAutoruz = new GlavAutoruz();
            glavAutoruz.Show();
            this.Close();
        }

        private bool IsLoginExists(string login)
        {
            bool result = false;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT COUNT(*) FROM [User] WHERE UserLogin = @Login";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Login", login);
                    connection.Open();
                    int count = (int)command.ExecuteScalar();
                    if (count > 0)
                    {
                        result = true;
                    }
                }
            }
            return result;
        }

        private void RegisterUser(string surname, string name, string patronymic, string login, string hashedPassword, string salt)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO [User] (UserSurname, UserName, UserPatronymic, UserLogin, UserPassword, Salt, RoleID) VALUES (@Surname, @Name, @Patronymic, @Login, @Password, @Salt, @RoleID)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Surname", surname);
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Patronymic", patronymic);
                    command.Parameters.AddWithValue("@Login", login);
                    command.Parameters.AddWithValue("@Password", hashedPassword);
                    command.Parameters.AddWithValue("@Salt", salt);
                    command.Parameters.AddWithValue("@RoleID", 2); 
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        private string GenerateSalt()
        {
            byte[] saltBytes = new byte[16];
            using (var rng = new RNGCryptoServiceProvider())
            {
                rng.GetBytes(saltBytes);
            }
            return Convert.ToBase64String(saltBytes);
        }

        private string HashPassword(string password, string salt)
        {
            using (var sha256 = SHA256.Create())
            {
                byte[] saltedPassword = Encoding.UTF8.GetBytes(password + salt);
                byte[] hash = sha256.ComputeHash(saltedPassword);
                return Convert.ToBase64String(hash);
            }
        }

        private void btnAutoruz_Click(object sender, EventArgs e)
        {
            GlavAutoruz glavAutoruz = new GlavAutoruz();
            glavAutoruz.Show();
            this.Close();
        }
    }
}
