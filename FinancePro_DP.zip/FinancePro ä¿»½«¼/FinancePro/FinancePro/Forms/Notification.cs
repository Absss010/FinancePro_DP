﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinancePro.Forms
{
    public partial class Notification : Form
    {
        private const string connectionString = "Data Source=DESKTOP-2JK9QLP;Initial Catalog=FinancePro;User ID=qwe;Password=qwe;Encrypt=False;TrustServerCertificate=True";
        private string userID;
        private string login;
        private int roleID;

        public Notification(string userID, string login, int roleID)
        {
            InitializeComponent();
            this.userID = userID;
            this.login = login;
            this.roleID = roleID;
            this.Load += Notification_Load;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNat.Text))
            {
                MessageBox.Show("Введите напоминание.");
                return;
            }

            string reminderText = txtNat.Text;
            DateTime reminderDate = dtpAdd.Value;

            AddReminder(reminderText, reminderDate);

            txtNat.Clear();

            MessageBox.Show("Напоминание успешно добавлено.");

            LoadAllReminders();
        }

        private void AddReminder(string reminderText, DateTime reminderDate)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO [Notification] (UserID, Message, Date) VALUES (@UserID, @Message, @Date)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    command.Parameters.AddWithValue("@Message", reminderText);
                    command.Parameters.AddWithValue("@Date", reminderDate);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        private void btnProsmotr_Click(object sender, EventArgs e)
        {
            DisplayTodaysReminders();
        }

        private void DisplayTodaysReminders()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Message FROM [Notification] WHERE UserID = @UserID AND Date = @Date";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    command.Parameters.AddWithValue("@Date", DateTime.Today);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    StringBuilder reminders = new StringBuilder();
                    while (reader.Read())
                    {
                        reminders.AppendLine((string)reader["Message"]);
                    }
                    reader.Close();

                    if (reminders.Length == 0)
                    {
                        MessageBox.Show("На сегодня нет напоминаний.");
                    }
                    else
                    {
                        MessageBox.Show($"Напоминания на сегодня:\n{reminders}");
                    }
                }
            }
        }

        private void Notification_Load(object sender, EventArgs e)
        {
            LoadAllReminders();
        }

        private void LoadAllReminders()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT NotificationID, Message, Date FROM [Notification] WHERE UserID = @UserID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgvProsmotr.DataSource = dataTable;
                    dgvProsmotr.Columns["NotificationID"].Visible = false; 
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvProsmotr.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите ненужное напоминание для удаления.");
                return;
            }

            int selectedNotificationID = (int)dgvProsmotr.SelectedRows[0].Cells["NotificationID"].Value;
            DeleteReminder(selectedNotificationID);

            MessageBox.Show("Напоминание успешно удалено.");

            LoadAllReminders();
        }

        private void DeleteReminder(int notificationID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM [Notification] WHERE NotificationID = @NotificationID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@NotificationID", notificationID);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Ocnovnay ocnovnay = new Ocnovnay(login, roleID, userID);
            ocnovnay.Show();
            this.Close();

        }
    }
}