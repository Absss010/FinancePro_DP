﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;
using Excel = Microsoft.Office.Interop.Excel;
using System.Drawing.Imaging;

namespace FinancePro.Forms
{
    public partial class RedactHistoryTransaction : Form
    {
        private const string connectionString = "Data Source=DESKTOP-2JK9QLP;Initial Catalog=FinancePro;User ID=qwe;Password=qwe;Encrypt=False;TrustServerCertificate=True";
        private string userID;
        private string login;
        private int roleID;

        public RedactHistoryTransaction(string userID, string login, int roleID)
        {
            InitializeComponent();
            this.userID = userID;
            this.login = login;
            this.roleID = roleID;
        }

        private void History_Load(object sender, EventArgs e)
        {
            LoadUsers();

            // Автоматически выбираем первого пользователя из списка, если он доступен
            if (cmbUser.Items.Count > 0)
            {
                cmbUser.SelectedIndex = 0;
                DataRowView selectedRow = cmbUser.SelectedItem as DataRowView;
                int selectedUserID = Convert.ToInt32(selectedRow["UserID"]);
                LoadTransactions($"AND t.UserID = {selectedUserID}"); // Загрузка транзакций для выбранного пользователя
            }
        }

        private void LoadUsers()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT UserID, UserName FROM [User]";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        if (dataTable.Rows.Count == 0)
                        {
                            MessageBox.Show("Нет доступных пользователей.");
                        }

                        cmbUser.DataSource = dataTable;
                        cmbUser.DisplayMember = "UserName";
                        cmbUser.ValueMember = "UserID";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке пользователей: {ex.Message}");
            }
        }

        private void LoadTransactions(string filter = "")
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT t.TransactionID, 
                                u.UserSurname AS 'Фамилия пользователя', 
                                u.UserName AS 'Имя пользователя', 
                                u.UserPatronymic AS 'Отчество пользователя', 
                                t.Amount AS 'Сумма', 
                                ty.TypeName AS 'Тип транзакции', 
                                c.CategoryName AS 'Категория', 
                                t.Date AS 'Дата',
                                cd.CardName AS 'Карта' 
                         FROM [Transaction] t
                         INNER JOIN [User] u ON t.UserID = u.UserID
                         INNER JOIN [Type] ty ON t.TypeID = ty.TypeID
                         INNER JOIN [Category] c ON t.CategoryID = c.CategoryID
                         INNER JOIN [Card] cd ON t.CardID = cd.CardID
                         WHERE 1=1 " + filter + @"
                         ORDER BY t.Date DESC";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dgvHistory.DataSource = dataTable;
                    dgvHistory.Columns["TransactionID"].Visible = false;
                }
            }
        }

        private void cbPlus_CheckedChanged(object sender, EventArgs e)
        {
            DataRowView selectedRow = cmbUser.SelectedItem as DataRowView;
            if (selectedRow != null && cbPlus.Checked)
            {
                cbMinus.Checked = false;

                int selectedUserID = Convert.ToInt32(selectedRow["UserID"]);
                LoadTransactions($"AND t.Amount > 0 AND t.UserID = {selectedUserID}");
            }
            else if (!cbMinus.Checked)
            {
                cmbUser_SelectedIndexChanged(sender, e);
            }
        }

        private void cbMinus_CheckedChanged(object sender, EventArgs e)
        {
            DataRowView selectedRow = cmbUser.SelectedItem as DataRowView;
            if (selectedRow != null && cbMinus.Checked)
            {
                cbPlus.Checked = false;

                int selectedUserID = Convert.ToInt32(selectedRow["UserID"]);
                LoadTransactions($"AND t.Amount < 0 AND t.UserID = {selectedUserID}");
            }
            else if (!cbPlus.Checked)
            {
                cmbUser_SelectedIndexChanged(sender, e);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            AdminPanel adminPanel = new AdminPanel(login, roleID, userID);
            adminPanel.Show();
            this.Close();
        }

        private void btnExPlus_Click(object sender, EventArgs e)
        {
            DataRowView selectedRow = cmbUser.SelectedItem as DataRowView;
            if (selectedRow != null)
            {
                int selectedUserID = Convert.ToInt32(selectedRow["UserID"]);
                ExportToExcel($"AND t.Amount > 0 AND t.UserID = {selectedUserID}");
            }
            else
            {
                MessageBox.Show("Выберите пользователя для экспорта данных.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExMinus_Click(object sender, EventArgs e)
        {
            DataRowView selectedRow = cmbUser.SelectedItem as DataRowView;
            if (selectedRow != null)
            {
                int selectedUserID = Convert.ToInt32(selectedRow["UserID"]);
                ExportToExcel($"AND t.Amount < 0 AND t.UserID = {selectedUserID}");
            }
            else
            {
                MessageBox.Show("Выберите пользователя для экспорта данных.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExAll_Click(object sender, EventArgs e)
        {
            DataRowView selectedRow = cmbUser.SelectedItem as DataRowView;
            if (selectedRow != null)
            {
                int selectedUserID = Convert.ToInt32(selectedRow["UserID"]);
                ExportToExcel($"AND t.UserID = {selectedUserID}");
            }
            else
            {
                MessageBox.Show("Выберите пользователя для экспорта данных.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExportToExcel(string filter = "")
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT u.UserSurname AS 'Фамилия пользователя', 
                        u.UserName AS 'Имя пользователя', 
                        u.UserPatronymic AS 'Отчество пользователя', 
                        t.Amount AS 'Сумма', 
                        ty.TypeName AS 'Тип транзакции', 
                        c.CategoryName AS 'Категория', 
                        t.Date AS 'Дата',
                        cd.CardName AS 'Карта' 
                 FROM [Transaction] t
                 INNER JOIN [User] u ON t.UserID = u.UserID
                 INNER JOIN [Type] ty ON t.TypeID = ty.TypeID
                 INNER JOIN [Category] c ON t.CategoryID = c.CategoryID
                 INNER JOIN [Card] cd ON t.CardID = cd.CardID
                 WHERE 1=1 " + filter + @"
                 ORDER BY t.Date DESC";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    Excel.Application excelApp = new Excel.Application();
                    excelApp.Visible = true;
                    Excel.Workbook workbook = excelApp.Workbooks.Add();
                    Excel.Worksheet worksheet = (Excel.Worksheet)workbook.Sheets[1];

                    for (int i = 0; i < dataTable.Columns.Count; i++)
                    {
                        worksheet.Cells[1, i + 1] = dataTable.Columns[i].ColumnName;
                    }

                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        for (int j = 0; j < dataTable.Columns.Count; j++)
                        {
                            if (dataTable.Columns[j].ColumnName == "Дата")
                            {
                                worksheet.Cells[i + 2, j + 1] = ((DateTime)dataTable.Rows[i][j]).ToString("yyyy-MM-dd");
                            }
                            else if (j == 3)
                            {
                                worksheet.Cells[i + 2, j + 1] = Convert.ToDecimal(dataTable.Rows[i][j]).ToString("N2");
                            }
                            else
                            {
                                worksheet.Cells[i + 2, j + 1] = dataTable.Rows[i][j].ToString();
                            }
                        }
                    }

                    // Форматирование столбца суммы
                    Excel.Range amountColumn = worksheet.Columns[4];
                    amountColumn.NumberFormat = "0.00";

                    worksheet.Columns.AutoFit();
                    MessageBox.Show("Данные успешно экспортированы в Excel.", "Экспорт завершен", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void UpdateCardBalance(int cardID, decimal amount)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Card SET AmountCard = AmountCard + @Amount WHERE CardID = @CardID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Amount", amount);
                    command.Parameters.AddWithValue("@CardID", cardID);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        private void DeleteTransaction(int transactionID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string selectQuery = "SELECT Amount, CardID FROM [Transaction] WHERE TransactionID = @TransactionID";
                using (SqlCommand selectCommand = new SqlCommand(selectQuery, connection))
                {
                    selectCommand.Parameters.AddWithValue("@TransactionID", transactionID);
                    connection.Open();
                    using (SqlDataReader reader = selectCommand.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            decimal amount = reader.GetDecimal(0);
                            int cardID = reader.GetInt32(1);

                            reader.Close();

                            UpdateCardBalance(cardID, -amount);

                            // Удаление транзакции
                            string deleteQuery = "DELETE FROM [Transaction] WHERE TransactionID = @TransactionID";
                            using (SqlCommand deleteCommand = new SqlCommand(deleteQuery, connection))
                            {
                                deleteCommand.Parameters.AddWithValue("@TransactionID", transactionID);
                                deleteCommand.ExecuteNonQuery();
                            }
                        }
                    }
                }
            }
        }

        private void btnDelet_Click(object sender, EventArgs e)
        {
            if (dgvHistory.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите транзакцию для удаления.");
                return;
            }

            int selectedTransactionID = (int)dgvHistory.SelectedRows[0].Cells["TransactionID"].Value;
            DeleteTransaction(selectedTransactionID);

            MessageBox.Show("Транзакция успешно удалена.");

            DataRowView selectedRow = cmbUser.SelectedItem as DataRowView;
            if (selectedRow != null)
            {
                int selectedUserID = Convert.ToInt32(selectedRow["UserID"]);
                LoadTransactions($"AND t.UserID = {selectedUserID}");
            }
            else
            {
                LoadTransactions();
            }
        }

        private void cmbUser_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbPlus.Checked = false;
            cbMinus.Checked = false;

            DataRowView selectedRow = cmbUser.SelectedItem as DataRowView;
            if (selectedRow != null)
            {
                int selectedUserID = Convert.ToInt32(selectedRow["UserID"]);
                LoadTransactions($"AND t.UserID = {selectedUserID}");
            }
            else
            {
                LoadTransactions();
            }
        }
    }
}