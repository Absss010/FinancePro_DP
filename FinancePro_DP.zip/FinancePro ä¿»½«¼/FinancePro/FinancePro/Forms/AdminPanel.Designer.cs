﻿namespace FinancePro.Forms
{
    partial class AdminPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminPanel));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.менюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnTransaction = new System.Windows.Forms.ToolStripMenuItem();
            this.редактированиеКатегорийToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnExitAc = new System.Windows.Forms.ToolStripMenuItem();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnBackup = new System.Windows.Forms.Button();
            this.регистрацияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.удалениеПользователейToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.менюToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(297, 24);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // менюToolStripMenuItem
            // 
            this.менюToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnTransaction,
            this.редактированиеКатегорийToolStripMenuItem,
            this.регистрацияToolStripMenuItem,
            this.удалениеПользователейToolStripMenuItem,
            this.btnExitAc});
            this.менюToolStripMenuItem.Name = "менюToolStripMenuItem";
            this.менюToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.менюToolStripMenuItem.Text = "Меню";
            // 
            // btnTransaction
            // 
            this.btnTransaction.Name = "btnTransaction";
            this.btnTransaction.Size = new System.Drawing.Size(236, 22);
            this.btnTransaction.Text = "Редактирование транзакциии";
            this.btnTransaction.Click += new System.EventHandler(this.btnTransaction_Click);
            // 
            // редактированиеКатегорийToolStripMenuItem
            // 
            this.редактированиеКатегорийToolStripMenuItem.Name = "редактированиеКатегорийToolStripMenuItem";
            this.редактированиеКатегорийToolStripMenuItem.Size = new System.Drawing.Size(236, 22);
            this.редактированиеКатегорийToolStripMenuItem.Text = "Редактирование категорий";
            this.редактированиеКатегорийToolStripMenuItem.Click += new System.EventHandler(this.редактированиеКатегорийToolStripMenuItem_Click);
            // 
            // btnExitAc
            // 
            this.btnExitAc.Name = "btnExitAc";
            this.btnExitAc.Size = new System.Drawing.Size(236, 22);
            this.btnExitAc.Text = "Выход из аккаунта";
            this.btnExitAc.Click += new System.EventHandler(this.btnExitAc_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(69, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 30);
            this.label3.TabIndex = 36;
            this.label3.Text = "Админ-панель";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(70, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(173, 38);
            this.label2.TabIndex = 37;
            this.label2.Text = "Можете отредактировать \r\nтранзакции и категории";
            // 
            // btnBackup
            // 
            this.btnBackup.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnBackup.Location = new System.Drawing.Point(102, 99);
            this.btnBackup.Name = "btnBackup";
            this.btnBackup.Size = new System.Drawing.Size(93, 32);
            this.btnBackup.TabIndex = 38;
            this.btnBackup.Text = "Бэкап БД";
            this.btnBackup.UseVisualStyleBackColor = true;
            this.btnBackup.Click += new System.EventHandler(this.btnExAll_Click);
            // 
            // регистрацияToolStripMenuItem
            // 
            this.регистрацияToolStripMenuItem.Name = "регистрацияToolStripMenuItem";
            this.регистрацияToolStripMenuItem.Size = new System.Drawing.Size(236, 22);
            this.регистрацияToolStripMenuItem.Text = "Регистрация пользователей ";
            this.регистрацияToolStripMenuItem.Click += new System.EventHandler(this.регистрацияToolStripMenuItem_Click);
            // 
            // удалениеПользователейToolStripMenuItem
            // 
            this.удалениеПользователейToolStripMenuItem.Name = "удалениеПользователейToolStripMenuItem";
            this.удалениеПользователейToolStripMenuItem.Size = new System.Drawing.Size(236, 22);
            this.удалениеПользователейToolStripMenuItem.Text = "Удаление пользователей";
            this.удалениеПользователейToolStripMenuItem.Click += new System.EventHandler(this.удалениеПользователейToolStripMenuItem_Click);
            // 
            // AdminPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(297, 144);
            this.Controls.Add(this.btnBackup);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AdminPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Админ-панель";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem менюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem btnTransaction;
        private System.Windows.Forms.ToolStripMenuItem btnExitAc;
        private System.Windows.Forms.ToolStripMenuItem редактированиеКатегорийToolStripMenuItem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnBackup;
        private System.Windows.Forms.ToolStripMenuItem регистрацияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem удалениеПользователейToolStripMenuItem;
    }
}