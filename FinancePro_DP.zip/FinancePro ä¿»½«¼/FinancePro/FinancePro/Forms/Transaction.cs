﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Data;
using System.Drawing;

namespace FinancePro.Forms
{
    public partial class Transaction : Form
    {
        private const string connectionString = "Data Source=DESKTOP-2JK9QLP;Initial Catalog=FinancePro;User ID=qwe;Password=qwe;Encrypt=False;TrustServerCertificate=True";
        private string userID;
        private string login;
        private int roleID;

        public Transaction(string userID, string login, int roleID)
        {
            InitializeComponent();
            this.userID = userID;
            this.login = login;
            this.roleID = roleID;
            cmbTranz.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCategory.DropDownStyle = ComboBoxStyle.DropDown;
            cmbTranz.DropDown += cmbTranz_DropDown;
            cmbCategory.DropDown += cmbCategory_DropDown;
            cmbCard.DropDownStyle = ComboBoxStyle.DropDownList; 
            cmbCard1.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCard2.DropDownStyle = ComboBoxStyle.DropDownList;

            cmbTranz.DisplayMember = "Value";
            cmbTranz.ValueMember = "Key";
            cmbCategory.DisplayMember = "Value";
            cmbCategory.ValueMember = "Key";
            cmbCard.DisplayMember = "CardName";
            cmbCard.ValueMember = "CardID";
            cmbCard1.DisplayMember = "CardName";
            cmbCard1.ValueMember = "CardID";
            cmbCard2.DisplayMember = "CardName";
            cmbCard2.ValueMember = "CardID";

            Load += Transaction_Load;
            cmbCard1.SelectedIndexChanged += cmbCard1_SelectedIndexChanged;
            cmbCard2.SelectedIndexChanged += cmbCard2_SelectedIndexChanged;
            btnPlus.Click += btnPlus_Click;
        }

        private void Transaction_Load(object sender, EventArgs e)
        {
            LoadCards();
            LoadCards1();
            LoadCards2();

            // Добавляем вызов методов для отображения начального баланса
            if (cmbCard1.SelectedValue != null)
            {
                int selectedCardID1 = (int)cmbCard1.SelectedValue;
                DisplayCardBalance1(selectedCardID1);
            }

            if (cmbCard2.SelectedValue != null)
            {
                int selectedCardID2 = (int)cmbCard2.SelectedValue;
                DisplayCardBalance2(selectedCardID2);
            }
        }

        private void LoadCards()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT CardID, CardName FROM Card WHERE UserID = @UserID";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userID);
                        connection.Open();

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        cmbCard.DataSource = dataTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке карт: {ex.Message}");
            }
        }

        private void LoadCards1()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT CardID, CardName FROM Card WHERE UserID = @UserID";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userID);
                        connection.Open();

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        cmbCard1.DataSource = dataTable;

                        // Устанавливаем начальный баланс
                        if (cmbCard1.SelectedValue != null)
                        {
                            int selectedCardID = (int)cmbCard1.SelectedValue;
                            DisplayCardBalance1(selectedCardID);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке карт: {ex.Message}");
            }
        }

        private void LoadCards2()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT CardID, CardName FROM Card WHERE UserID = @UserID";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userID);
                        connection.Open();

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        if (dataTable.Rows.Count == 0)
                        {
                            MessageBox.Show("Нет доступных карт для этого пользователя.");
                        }

                        cmbCard2.DataSource = dataTable;

                        // Устанавливаем начальный баланс
                        if (cmbCard2.SelectedValue != null)
                        {
                            int selectedCardID = (int)cmbCard2.SelectedValue;
                            DisplayCardBalance2(selectedCardID);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке карт: {ex.Message}");
            }
        }

        private void cmbCard1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCard1.SelectedItem != null)
            {
                DataRowView selectedRow = cmbCard1.SelectedItem as DataRowView;
                if (selectedRow != null)
                {
                    int selectedCardID = Convert.ToInt32(selectedRow["CardID"]);
                    DisplayCardBalance1(selectedCardID);
                }
            }
        }

        private void cmbCard2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCard2.SelectedItem != null)
            {
                DataRowView selectedRow = cmbCard2.SelectedItem as DataRowView;
                if (selectedRow != null)
                {
                    int selectedCardID = Convert.ToInt32(selectedRow["CardID"]);
                    DisplayCardBalance2(selectedCardID);
                }
            }
        }

        private void DisplayCardBalance1(int cardID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT AmountCard FROM Card WHERE CardID = @CardID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CardID", cardID);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        decimal amountCard = (decimal)reader["AmountCard"];
                        labBalans1.Text = $"Баланс: {amountCard:C}"; // Форматирование как валюту
                        labBalans1.ForeColor = amountCard >= 0 ? Color.Lime : Color.Red;
                    }
                    reader.Close();
                }
            }
        }

        private void DisplayCardBalance2(int cardID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT AmountCard FROM Card WHERE CardID = @CardID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CardID", cardID);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        decimal amountCard = (decimal)reader["AmountCard"];
                        labBalans2.Text = $"Баланс: {amountCard:C}"; // Форматирование как валюту
                        labBalans2.ForeColor = amountCard >= 0 ? Color.Lime : Color.Red;
                    }
                    reader.Close();
                }
            }
        }

        private decimal GetCardBalance(int cardID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT AmountCard FROM Card WHERE CardID = @CardID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CardID", cardID);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    return result != null ? Convert.ToDecimal(result) : 0;
                }
            }
        }

        private void cmbTranz_DropDown(object sender, EventArgs e)
        {
            cmbTranz.Items.Clear();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT TypeID, TypeName FROM [Type]";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        cmbTranz.Items.Add(new KeyValuePair<int, string>((int)reader["TypeID"], (string)reader["TypeName"]));
                    }
                    reader.Close();
                }
            }
        }

        private void cmbCategory_DropDown(object sender, EventArgs e)
        {
            cmbCategory.Items.Clear();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT CategoryID, CategoryName FROM [Category] WHERE CategoryName != 'Перевод между своими счетами'";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        cmbCategory.Items.Add(new KeyValuePair<int, string>((int)reader["CategoryID"], (string)reader["CategoryName"]));
                    }
                    reader.Close();
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Ocnovnay ocnovnay = new Ocnovnay(login, roleID, userID);
            ocnovnay.Show();
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Проверка, заполнены ли все поля
            if (cmbTranz.SelectedItem == null || (cmbCategory.SelectedItem == null && string.IsNullOrEmpty(cmbCategory.Text)) || string.IsNullOrEmpty(txtSumma.Text) || cmbCard.SelectedItem == null)
            {
                MessageBox.Show("Заполните все поля.");
                return;
            }

            // Получаем выбранные значения из ComboBox'ов
            var selectedTransaction = (KeyValuePair<int, string>)cmbTranz.SelectedItem;

            KeyValuePair<int, string> selectedCategory;
            if (cmbCategory.SelectedItem != null)
            {
                selectedCategory = (KeyValuePair<int, string>)cmbCategory.SelectedItem;
            }
            else
            {
                // Если категория введена вручную, добавляем её в базу данных
                string newCategoryName = cmbCategory.Text;
                int newCategoryId = GetCategoryIdOrAddNew(newCategoryName);
                selectedCategory = new KeyValuePair<int, string>(newCategoryId, newCategoryName);
            }

            // Проверка, является ли сумма числом
            if (!decimal.TryParse(txtSumma.Text, out decimal amount))
            {
                MessageBox.Show("Сумма должна быть числом.");
                return;
            }

            // Если выбран тип транзакции 1, сумма должна быть отрицательной
            if (selectedTransaction.Key == 1)
            {
                amount = -amount;
            }

            int selectedCardID = (int)cmbCard.SelectedValue;

            // Проверяем, достаточно ли средств на карте для выполнения транзакции
            decimal currentBalance = GetCardBalance(selectedCardID);
            if (currentBalance + amount < 0)
            {
                MessageBox.Show("На карте недостаточно средств для выполнения транзакции.");
                return;
            }

            DateTime transactionDate = dtpAdd.Value;

            // Добавляем транзакцию
            AddTransaction(selectedTransaction.Key, selectedCategory.Key, amount, transactionDate, selectedCardID);

            // Обновляем баланс карты
            UpdateCardBalance(selectedCardID, amount);

            // Обновляем отображение балансов карт
            if (cmbCard1.SelectedValue != null)
            {
                DisplayCardBalance1((int)cmbCard1.SelectedValue);
            }
            if (cmbCard2.SelectedValue != null)
            {
                DisplayCardBalance2((int)cmbCard2.SelectedValue);
            }

            // Сбрасываем поля
            cmbTranz.SelectedIndex = -1;
            cmbCategory.SelectedIndex = -1;
            cmbCard.SelectedIndex = -1;
            txtSumma.Clear();
            cmbCategory.Text = string.Empty; 

            MessageBox.Show("Транзакция успешно добавлена.");
        }

        private int GetCategoryIdOrAddNew(string categoryName)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Проверяем, существует ли категория
                string selectQuery = "SELECT CategoryID FROM [Category] WHERE CategoryName = @CategoryName";
                using (SqlCommand selectCommand = new SqlCommand(selectQuery, connection))
                {
                    selectCommand.Parameters.AddWithValue("@CategoryName", categoryName);
                    object result = selectCommand.ExecuteScalar();
                    if (result != null)
                    {
                        return (int)result;
                    }
                }

                // Если категория не существует, добавляем её
                string insertQuery = "INSERT INTO [Category] (CategoryName) VALUES (@CategoryName); SELECT SCOPE_IDENTITY();";
                using (SqlCommand insertCommand = new SqlCommand(insertQuery, connection))
                {
                    insertCommand.Parameters.AddWithValue("@CategoryName", categoryName);
                    object result = insertCommand.ExecuteScalar();
                    return Convert.ToInt32(result);
                }
            }
        }

        private void AddTransaction(int transactionID, int categoryID, decimal amount, DateTime transactionDate, int cardID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO [Transaction] (UserID, Amount, TypeID, CategoryID, Date, CardID) VALUES (@UserID, @Amount, @TypeID, @CategoryID, @Date, @CardID)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    command.Parameters.AddWithValue("@Amount", amount);
                    command.Parameters.AddWithValue("@TypeID", transactionID);
                    command.Parameters.AddWithValue("@CategoryID", categoryID);
                    command.Parameters.AddWithValue("@Date", transactionDate); 
                    command.Parameters.AddWithValue("@CardID", cardID); 

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        private void UpdateCardBalance(int cardID, decimal amount)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Card SET AmountCard = AmountCard + @Amount WHERE CardID = @CardID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Amount", amount);
                    command.Parameters.AddWithValue("@CardID", cardID);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            if (cmbCard1.SelectedItem == null || cmbCard2.SelectedItem == null || string.IsNullOrEmpty(txtTransferAmount.Text))
            {
                MessageBox.Show("Выберите обе карты и введите сумму для перевода.");
                return;
            }

            if ((int)cmbCard1.SelectedValue == (int)cmbCard2.SelectedValue)
            {
                MessageBox.Show("Нельзя выбрать одну и ту же карту для перевода.");
                return;
            }

            if (!decimal.TryParse(txtTransferAmount.Text, out decimal amount))
            {
                MessageBox.Show("Сумма перевода должна быть числом.");
                return;
            }

            int selectedCardID1 = (int)cmbCard1.SelectedValue;
            int selectedCardID2 = (int)cmbCard2.SelectedValue;

            // Получаем баланс выбранных карт
            decimal balance1 = GetCardBalance(selectedCardID1);
            decimal balance2 = GetCardBalance(selectedCardID2);

            // Проверяем, достаточно ли средств на первой карте для перевода
            if (balance1 < amount)
            {
                MessageBox.Show("На первой карте недостаточно средств для выполнения перевода.");
                return;
            }

            // Выполняем перевод
            UpdateCardBalance(selectedCardID1, -amount); // Списание с первой карты
            UpdateCardBalance(selectedCardID2, amount); // Зачисление на вторую карту

            AddTransaction(1, 8, -amount, DateTime.Now, selectedCardID1); // Списание с первой карты
            AddTransaction(2, 8, amount, DateTime.Now, selectedCardID2); // Зачисление на вторую карту

            // Обновляем отображение балансов карт
            DisplayCardBalance1(selectedCardID1);
            DisplayCardBalance2(selectedCardID2);

            txtTransferAmount.Clear();
            cmbCard1.SelectedIndex = -1;
            cmbCard2.SelectedIndex = -1;

            MessageBox.Show("Перевод успешно выполнен.");
        }
    }
}