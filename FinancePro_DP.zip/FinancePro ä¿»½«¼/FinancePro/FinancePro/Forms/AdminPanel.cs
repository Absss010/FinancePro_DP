﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinancePro.Forms
{
    public partial class AdminPanel : Form
    {
        private string login;
        private int roleID;
        private string userID;
        private const string connectionString = "Data Source=DESKTOP-2JK9QLP;Initial Catalog=FinancePro;User ID=qwe;Password=qwe;Encrypt=False;TrustServerCertificate=True";

        public AdminPanel(string login, int roleID, string userID)
        {
            InitializeComponent();
            this.login = login;
            this.roleID = roleID;
            this.userID = userID;
        }

        private void btnTransaction_Click(object sender, EventArgs e)
        {
            RedactHistoryTransaction redactHistoryTransaction = new RedactHistoryTransaction(userID, login, roleID);
            redactHistoryTransaction.Show();
            this.Close();
        }

        private void btnExitAc_Click(object sender, EventArgs e)
        {
            GlavAutoruz glavAutoruz = new GlavAutoruz();
            glavAutoruz.Show();
            this.Close();
        }

        private void редактированиеКатегорийToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RedactCategory redactCategory = new RedactCategory(userID, login, roleID);
            redactCategory.Show();
            this.Close();
        }

        private void btnExAll_Click(object sender, EventArgs e)
        {
            try
            {
                // Общий путь для резервных копий, убедитесь, что он доступен для записи
                string backupPath = @"F:\Backup\FinancePro_backup.bak";

                // Запрос на создание резервной копии
                string query = $"BACKUP DATABASE FinancePro TO DISK = '{backupPath}'";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                    connection.Close();
                }

                MessageBox.Show("Резервная копия базы данных успешно создана", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании резервной копии: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void регистрацияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Registr_Users registr_Users = new Registr_Users(login, roleID, userID);
            registr_Users.Show();
            this.Close();
        }

        private void удалениеПользователейToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Del_Users del_Users = new Del_Users(login, roleID, userID);
            del_Users.Show();
            this.Close();
        }
    }
}
