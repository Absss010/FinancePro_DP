﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinancePro.Forms
{
    public partial class Del_Users : Form
    {
        private string login;
        private int roleID;
        private string userID;
        private const string connectionString = "Data Source=DESKTOP-2JK9QLP;Initial Catalog=FinancePro;User ID=qwe;Password=qwe;Encrypt=False;TrustServerCertificate=True";

        public Del_Users(string login, int roleID, string userID)
        {
            InitializeComponent();
            this.login = login;
            this.roleID = roleID;
            this.userID = userID;
        }

        private void Del_Users_Load(object sender, EventArgs e)
        {
            LoadUsers();
        }

        private void LoadUsers()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT UserID, UserSurname, UserName, UserPatronymic, UserLogin, RoleID FROM [User]";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dgvUsers.DataSource = dataTable;

                // Установка русских заголовков столбцов
                dgvUsers.Columns["UserID"].HeaderText = "ID Пользователя";
                dgvUsers.Columns["UserSurname"].HeaderText = "Фамилия";
                dgvUsers.Columns["UserName"].HeaderText = "Имя";
                dgvUsers.Columns["UserPatronymic"].HeaderText = "Отчество";
                dgvUsers.Columns["UserLogin"].HeaderText = "Логин";
                dgvUsers.Columns["RoleID"].HeaderText = "ID Роли";
            }
        }

        private void txtUsers_TextChanged(object sender, EventArgs e)
        {
            DataTable dataTable = dgvUsers.DataSource as DataTable;
            if (dataTable != null)
            {
                dataTable.DefaultView.RowFilter =
                    string.Format("UserSurname LIKE '%{0}%' OR UserName LIKE '%{0}%' OR UserLogin LIKE '%{0}%'", txtUsers.Text);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvUsers.SelectedRows.Count > 0)
            {
                int selectedUserId = Convert.ToInt32(dgvUsers.SelectedRows[0].Cells["UserID"].Value);
                DeleteUser(selectedUserId);
                LoadUsers();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите пользователя для удаления.");
            }
        }

        private void DeleteUser(int userID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM [User] WHERE UserID = @UserID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        private void btnGlav_Click(object sender, EventArgs e)
        {
            AdminPanel adminPanel = new AdminPanel(login, roleID, userID);
            adminPanel.Show();
            this.Close();
        }
    }
}